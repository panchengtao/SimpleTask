﻿using Abp.MultiTenancy;
using Sedion.SimpleTask.Users;

namespace Sedion.SimpleTask.MultiTenancy
{
    public class Tenant : AbpTenant<Tenant, User>
    {
        public Tenant()
        {
            
        }

        public Tenant(string tenancyName, string name)
            : base(tenancyName, name)
        {
        }
    }
}