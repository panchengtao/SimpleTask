﻿namespace Sedion.SimpleTask
{
    public class SimpleTaskConsts
    {
        public const string LocalizationSourceName = "SimpleTask";
    }
}