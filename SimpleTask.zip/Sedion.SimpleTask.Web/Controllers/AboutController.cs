﻿using System.Web.Mvc;

namespace Sedion.SimpleTask.Web.Controllers
{
    public class AboutController : SimpleTaskControllerBase
    {
        public ActionResult Index()
        {
            return View();
        }
	}
}